export const environment = {
  production: false,
  demo: 'demo1',
  SERVER_URL: 'https://geonixbackend.in',
  // SERVER_URL: 'https://localhost:443',
  MOLLA_URL: 'http://localhost:1337',
  razorKey:"rzp_live_gCGATpaXPGMbOG",
  // razorKey:"rzp_test_vkkodcyTNkrtUJ"
};