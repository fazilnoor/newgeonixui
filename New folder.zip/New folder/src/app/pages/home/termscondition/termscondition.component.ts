import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'molla-termscondition',
  templateUrl: './termscondition.component.html',
  styleUrls: ['./termscondition.component.scss']
})
export class TermsconditionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
