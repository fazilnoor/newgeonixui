import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'molla-about-nutri',
  templateUrl: './about-nutri.component.html',
  styleUrls: ['./about-nutri.component.scss']
})
export class AboutNutriComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
