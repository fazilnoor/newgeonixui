function sendConversion(){
    gtag('event', 'conversion', {
        'send_to': 'AW-11105694379/2w5ACJnY244YEKvlza8p',
        'value': 1.0,
        'currency': 'INR',
        'transaction_id': ''
    });
}

function sendCartConversion()
{
    gtag('event', 'conversion',  {
        'send_to': 'AW-11105694379/V0VjCP6e1o4YEKvlza8p',
        'value': 1.0,
        'currency': 'INR'
    });
}